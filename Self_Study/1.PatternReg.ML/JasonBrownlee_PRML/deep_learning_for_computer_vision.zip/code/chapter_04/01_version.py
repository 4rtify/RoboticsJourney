# check Pillow version number
import PIL
print('Pillow Version:', PIL.__version__)